package com.vinayak09.EmergencyBloodline.listeners;

public interface MyOnClickListener {
    void getPosition(int position);
}
